package com.example.accessingdatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccessingDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
